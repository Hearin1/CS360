package com.example.inventoryapp;

/**
 * Represents a product entity with an ID, name, and description.
 */
public class Product {
    private int _id;
    private String _productname;
    private String _description;


    // Default constructor
    public Product(){

    }



    /**
     * Constructor for initializing all fields.
     * @param id The unique ID of the product.
     * @param productname The name of the product.
     * @param description The description of the product.
     */
    public Product(int id,String productname, String description){
        this._id =id;
        this._productname = productname;
        this._description =description;
    }

    /**
     * Constructor for initializing a product without an ID.
     * @param productname The name of the product.
     * @param description The description of the product.
     */
    public  Product(String productname, String description){
        this._productname = productname;
        this._description = description;
    }


    // Getters and Setters with inline comments for each method.
    public int getID() {
        return _id;
    } // Returns the product ID

    public void setID(int id) {
        this._id = id;
    } // Sets the product ID

    public String getProductName() {
        return _productname;
    } // Returns the product name

    public void setProductName(String productname) {
        this._productname = productname;
    } // Sets the product name

    public String getDescription() {
        return _description;
    } // Returns the product description

    public void setDescription(String description) {
        this._description = description;
    } // Sets the product description
}
